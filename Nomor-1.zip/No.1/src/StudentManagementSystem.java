import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Student {
    private int id;
    private String name;
    private String major;
    private int semester;
    private int year;
    private String gender;

    public Student(int id, String name, String major, int semester, int year, String gender) {
        this.id = id;
        this.name = name;
        this.major = major;
        this.semester = semester;
        this.year = year;
        this.gender = gender;
    }

    // Getter methods
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getMajor() {
        return major;
    }

    public int getSemester() {
        return semester;
    }

    public int getYear() {
        return year;
    }

    public String getGender() {
        return gender;
    }

    @Override
    public String toString() {
        return "ID: " + id + "\nName: " + name + "\nMajor: " + major + "\nSemester: " + semester + "\nYear: " + year
                + "\nGender: " + gender;
    }
}

public class StudentManagementSystem {
    private static List<Student> students = new ArrayList<>();
    private static int nextId = 1;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nMenu Registrasi:");
            System.out.println("1. Tambahkan Data Mahasiswa");
            System.out.println("2. Perbaharui Data Mahasiswa");
            System.out.println("3. Lihat Semua Data Mahasiswa");
            System.out.println("4. Liat Mahasiswa Berdasarkan ID");
            System.out.println("5. Selesai");
            System.out.print("Pilih Menu: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addStudent(scanner);
                    break;
                case 2:
                    updateStudent(scanner);
                    break;
                case 3:
                    viewAllStudents();
                    break;
                case 4:
                    viewStudentById(scanner);
                    break;
                case 5:
                    System.out.println("Terima kasih! ");
                    break;
                default:
                    System.out.println("Pilihan tidak valid, pilih yang lain.");
            }
        } while (choice != 5);
    }

    private static void addStudent(Scanner scanner) {
        System.out.print("Nama: ");
        String name = scanner.next();
        System.out.print("Jurusan: ");
        String major = scanner.next();
        System.out.print("Semester: ");
        int semester = scanner.nextInt();
        System.out.print("Tahun: ");
        int year = scanner.nextInt();
        System.out.print("Gender: ");
        String gender = scanner.next();

        Student student = new Student(nextId++, name, major, semester, year, gender);
        students.add(student);
        System.out.println("Mahasiswa berhasil ditambahkan !");
    }

    private static void updateStudent(Scanner scanner) {
        System.out.print("Masukkan ID mahasiswa yang akan diganti: ");
        int idToUpdate = scanner.nextInt();

        for (Student student : students) {
            if (student.getId() == idToUpdate) {
                System.out.print("Masukkan nama baru: ");
                String name = scanner.next();
                System.out.print("Masukkan jurusan baru: ");
                String major = scanner.next();
                System.out.print("Masukkan semester baru: ");
                int semester = scanner.nextInt();
                System.out.print("Masukkan tahun baru: ");
                int year = scanner.nextInt();
                System.out.print("Masukkan gender baru: ");
                String gender = scanner.next();

                student = new Student(idToUpdate, name, major, semester, year, gender);
                System.out.println("Data mahasiswa berhasil di update! ");
                return;
            }
        }
        System.out.println("Student with ID " + idToUpdate + " not found.");
    }

    private static void viewAllStudents() {
        if (students.isEmpty()) {
            System.out.println("Mahasiswa tidak terdata.");
            return;
        }

        System.out.println("Daftar mahasiswa: ");
        for (Student student : students) {
            System.out.println(student);
        }
    }

    private static void viewStudentById(Scanner scanner) {
        System.out.print("Masukkan ID mahasiswa ");
        int idToView = scanner.nextInt();

        for (Student student : students) {
            if (student.getId() == idToView) {
                System.out.println("Detail mahasiswa:");
                System.out.println(student);
                return;
            }
        }
        System.out.println("Student with ID " + idToView + " not found.");
    }
}
